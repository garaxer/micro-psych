"use strict";
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule ? mod : { default: mod };
  };
var _a;
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = exports.app = void 0;
var serverless_express_1 = __importDefault(
  require("@vendia/serverless-express")
);
var express_1 = __importDefault(require("express"));
var PORT = (_a = process.env.PORT) !== null && _a !== void 0 ? _a : 8081;
exports.app = express_1.default();
exports.app.get("/", function (req, res) {
  res.send(
    "Craig's Counselling Toowoomba. Contact craig@craigscounselling.com for an appointment"
  );
});
exports.app.get("/matt", function (req, res) {
  res.send("Thanks Matt");
});
exports.app.listen(PORT, function () {
  return console.log("Listening on 9000");
});
exports.handler = serverless_express_1.default({ app: exports.app });
//# sourceMappingURL=index.js.map
